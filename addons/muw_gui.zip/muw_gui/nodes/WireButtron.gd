extends Area2D
class_name WireArea

func _ready() -> void:
	print("!")
	connect("mouse_entered",update_last_wire)
	connect("mouse_exited",del_last_wire)

func update_last_wire() -> void:
	print("!")
	GG.last_wire = get_node("../")

func del_last_wire() -> void:
	GG.last_wire = null
