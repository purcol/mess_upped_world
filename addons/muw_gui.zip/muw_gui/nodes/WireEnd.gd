extends Sprite2D
class_name WireEnd

@export var wire_end:WireResource = null
@onready var wire_texture = get_node("./../..").whire_texture
@export var con_path:NodePath = NodePath("")
var con_node:WireEnd = null
enum TYPE {MAIN, SUB}
var current_type := TYPE.SUB

func _ready() -> void:
	z_index = -1
	if con_path != NodePath(""): 
		con_node = get_node(con_path)
		try_to_connect_ends(con_node)
	#add_child(WireButtron.new())
	add_child(WireArea.new())

func _process(_delta: float) -> void:
	if con_node != null: texture = null
	else: texture = wire_texture
	
	if con_path != NodePath(""): 
		con_node = get_node(con_path)
		try_to_connect_ends(con_node)
	queue_redraw()

func try_to_connect_ends(node:WireEnd) -> bool:
	if node == null: return false
	con_node = node
	current_type = TYPE.MAIN
	node.con_node = self
	node.current_type = TYPE.SUB
	return true

func get_wire_base_offset(side) -> Vector2:
	if side == 0: #up
		return Vector2(0,6)
	elif side == 1: #down
		return Vector2(0,-6)
	elif side == 2: #left
		return Vector2(0,6)
	elif side == 3: #right
		return Vector2(0,-6)
	return Vector2(0,0)

func _draw() -> void:
	if current_type != TYPE.MAIN or con_node == null: return
	var sub_wire_pos := (con_node.global_position - global_position)/scale \
							   +get_wire_base_offset(con_node.wire_end.SIDE)
	var distance := Vector2.ZERO.distance_to(sub_wire_pos)
	var vector := Vector2(1.2,1.2)*( Vector2(distance,0).rotated(Vector2(0,0).angle_to_point(sub_wire_pos)) )
	
	draw_line(Vector2(-5,-5)*vector.normalized(),vector,Color("#16171c"),6)
	draw_line(Vector2(-5,-5)*vector.normalized(),vector,Color("#232228"),4)
	#draw_line(Vector2(-5,-5)*vector.normalized(),Vector2(1.2,1.2)*vector,Color("d82228ff"),2)
