@tool
#@icon()
class_name DescButton
extends TextureButton

@export var texture:Texture2D
@export var texture_active:Texture2D
@export var title:String = ""
@export var desc:String = ""
@export var styles:Dictionary[String,Color] = {}

func _process(delta: float) -> void:
	texture_normal = texture
	texture_pressed = texture_active
	texture_hover = texture_active
	texture_disabled = texture
	texture_focused = texture_active
