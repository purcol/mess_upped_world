@tool
extends Control
class_name SimpleMonitor

#func _enter_tree() -> void:
	#clip_contents = true

func _ready() -> void:
	create_texture()
	create_clip_control()

func create_texture() -> void:
	var texture:NinePatchRect = NinePatchRect.new()
	texture.texture = load("res://addons/muw_gui/nodes/monitors/monitor_texture.png")
	texture.patch_margin_bottom = 40
	texture.patch_margin_top = 40
	texture.patch_margin_right = 110
	texture.patch_margin_left = 110
	
	texture.anchor_right = 1
	texture.anchor_bottom = 1
	texture.offset_bottom = 40
	texture.offset_right = 40
	texture.offset_top = -40
	texture.offset_left = -40
	add_child.call_deferred(texture,false,Node.INTERNAL_MODE_BACK)

func create_clip_control() -> void:
	var clip:Control = Control.new()
	clip.name = "ClipControl"
	clip.anchor_right = 1
	clip.anchor_bottom = 1
	clip.clip_contents = true
	add_child.call_deferred(clip,false,InternalMode.INTERNAL_MODE_DISABLED)

func _get_configuration_warnings() -> PackedStringArray:
	var flag:bool = true
	for node in get_children():
		if node.is_class("Control"):
			if node.clip_contents == true:
				flag = false
				break
	if flag: return ["Monitor needs Control node whith clip_contents to work!"]
	return []
