@tool
extends MonitorCL

##@experimental: Класс и особено его методы не стабильны.
## Интерактивная версия [MonitorCL] добовляющая возможность создовать кнопки.
class_name MonitorCLI

## Если ture выполняет [method delete_buttons] перед [method draw_ui]. НЕ ВЫКЛЮЧАТЬ! 
@export var force_button_deletion_on_draw_ui:bool = true

#region gen
## Создаёт [MenuButton] (если [param is_popup] [code]false[/code], то [Button]) с именем [param stirng],
## в позиции [param pos] и там же с таким той же стокой отрисовывает текст.
## [param is_blocked] текста - [code]false[/code]. (См. [method MonitorCL.draw_text])
func create_button(stirng:String,pos:Vector2i,is_popup:bool=false) -> void:
	if get_local_text_position(pos).y <= line_size.y+1: return
	var button:Button = MenuButton.new() if is_popup else Button.new()
	button.name = stirng; button.size = Vector2(stirng.length() * char_size.x, char_size.y)
	button.position = get_local_text_position(pos)
	button.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	add_child(button)
	draw_text(pos,stirng,false)

## Удаляет всех детей класса [BaseButton].
func delete_buttons(include_internal:bool=true) -> void:
	for node in get_children(include_internal):
		if node is BaseButton: node.queue_free()
#endregion gen

#region drawing
## Функция для груписования [method MonitorCL.draw_*] функций в не редактора.
func draw_ui() -> void:
	if !Engine.is_editor_hint():
		if force_button_deletion_on_draw_ui: delete_buttons()
		fill_with()
		draw_line_cube(Vector2i(3,2),Vector2i(6,7))
		draw_line_cube(Vector2i(8,10),Vector2i(11,18))
		draw_text(Vector2i(2,11),"АБАБФ10пВЫ")
		draw_hor_line(9)
		draw_core_ui()
		if is_scrollable: draw_ver_line(line_size.x-2,true)
		
		create_button("АБАБФ",Vector2i(2,11))

#func editor_draw_ui() -> void: pass
#endregion drawing
