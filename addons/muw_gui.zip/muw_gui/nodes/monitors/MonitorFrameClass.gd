@tool
@icon("res://addons/muw_gui/nodes/monitors/monitor_texture.png")
extends NinePatchRect
class_name MonitorFrame

@export var monitor_texture:Texture2D = load("res://addons/muw_gui/nodes/monitors/monitor_texture.png")
@export var whire_texture:Texture2D = load("res://addons/muw_gui/nodes/monitors/wire_end.png")
@export var wire_ends:Array[WireResource] = [] :
	get:
		return wire_ends
	set(value):
		wire_ends = value
		update_wiers(true)
var old_wire_ends := wire_ends

func _enter_tree() -> void:
	texture = monitor_texture
	patch_margin_bottom = 40
	patch_margin_top = 40
	patch_margin_right = 110
	patch_margin_left = 110

func _process(_delta: float) -> void:
	if custom_minimum_size.x < patch_margin_right+patch_margin_left:
		custom_minimum_size.x = patch_margin_right+patch_margin_left
	if custom_minimum_size.y < patch_margin_bottom+patch_margin_top:
		custom_minimum_size.y = patch_margin_bottom+patch_margin_top
	
	for i:WireResource in wire_ends:
		if i != null:
			if i.position_mode == 1:
				if i.offset < 0 or i.offset > 1: i.offset = clamp(i.offset, 0, 1)
	

	if old_wire_ends != wire_ends: update_wiers(false,true)
	old_wire_ends == wire_ends
	#custom_minimum_size = Vector2(patch_margin_right+patch_margin_left, patch_margin_bottom+patch_margin_top)

func check_wire_node() -> void:
	if !has_node("WireSnds"):
		var node:Node2D = Node2D.new(); node.name = "WireSnds"
		add_child(node)

func add_wiers() -> void:
	check_wire_node()
	
	for i in wire_ends.size():
		if wire_ends[i] != null: wire_ends[i].id = str(i)
	
	for wire:WireResource in wire_ends:
		if wire == null: continue
		var sprite:WireEnd = WireEnd.new()
		sprite.name = str(get_node("WireSnds").get_child_count())
		sprite.texture = whire_texture
		sprite.scale = Vector2(9.65,9.65)
		sprite.wire_end = wire
		sprite.wire_end.id = wire.id
		
		if wire.SIDE == 0: #up
			sprite.rotation_degrees = 0
			sprite.offset.y = -3
		elif wire.SIDE == 1: #down
			sprite.rotation_degrees = 180
			sprite.offset.y = 3
		elif wire.SIDE == 2: #left
			sprite.rotation_degrees = 270
			sprite.offset.x = -3
		elif wire.SIDE == 3: #right
			sprite.rotation_degrees = 90
			sprite.offset.x = 3
		sprite.position = get_wire_offset(wire.SIDE,sprite.scale,wire.position_mode,wire.offset)
		get_node("WireSnds").add_child(sprite)

func get_wire_defalt_offset(side:int,sprite_scale:Vector2) -> Vector2:
	if side == 0: #up
		return Vector2(sprite_scale.x*3,0)
	elif side == 1: #down
		return Vector2(sprite_scale.x*3,size.y+sprite_scale.y*6)
	elif side == 2: #left
		return Vector2(-sprite_scale.x*3,0)
	elif side == 3: #right
		return Vector2(size.x+sprite_scale.x*3,0)
	return Vector2.ZERO

func get_wire_offset(side:int,sprite_scale:Vector2,is_proc_mode:bool,amount:float) -> Vector2:
	if is_proc_mode: amount = clamp(amount, 0, 1)
	var defalt := get_wire_defalt_offset(side,sprite_scale)
	var stripedd_size = size-(sprite_scale*Vector2(6,6))
	if side == 0: #up
		defalt += Vector2(stripedd_size.x*amount,0) if is_proc_mode else Vector2(amount,0)
	elif side == 1: #down
		defalt += Vector2(stripedd_size.x*amount,0) if is_proc_mode else Vector2(amount,0)
	elif side == 2: #left
		defalt += Vector2(0,stripedd_size.y*amount) if is_proc_mode else Vector2(0,-amount)
	elif side == 3: #right
		defalt += Vector2(0,stripedd_size.y*amount) if is_proc_mode else Vector2(0,-amount)
	return defalt

func get_wire_roattion(side:int) -> int:
	if side == 0: #up
		return 0
	elif side == 1: #down
		return 180
	elif side == 2: #left
		return 270
	elif side == 3: #right
		return 90
	return 0

func remove_wiers() -> void:
	check_wire_node()
	
	for node in get_node("WireSnds").get_children():
		node.queue_free()

func update_wiers(readd:bool=false,rerotate:bool=false) -> void:
	if readd:
		remove_wiers()
		add_wiers()
	else:
		check_wire_node()
		for sprite:WireEnd in get_node("WireSnds").get_children():
			sprite.position = get_wire_offset(sprite.wire_end.SIDE,sprite.scale,sprite.wire_end.position_mode,sprite.wire_end.offset)
			if rerotate:
				sprite.rotation_degrees = get_wire_roattion(sprite.wire_end.SIDE)

func _get_configuration_warnings() -> PackedStringArray:
	var flag:bool = true
	for node in get_children():
		if node is MonitorControl or node is MonitorCL: flag = false; break
	if flag: return ["Monitor needs 1 MonitorControl to work"]
	return []
