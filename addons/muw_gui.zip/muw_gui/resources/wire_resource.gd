extends Resource
class_name WireResource

@export_enum("UP","DOWN","LEFT","RIGHT") var SIDE = 0
@export_enum("FIXED","PROCENT") var position_mode = 0
@export var offset:float = 0
@export var id:StringName = ""
